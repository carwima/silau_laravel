<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PelangganController extends Controller
{
    
/* SESSION CHECK
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
*/
    public function index(Request $request){
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
            else{                
                //codestarthere
                $pelanggan = DB::table('pelanggan')->where('id',$request->session()->get('id'))->first();
                $total = DB::table('transaksi')
                    ->where('id_pelanggan',$request->session()->get('id'))
                    ->select(DB::raw('count(id) as total'))->first();
                return view('pelanggan2/master',['pelanggan'=>$pelanggan, 'total'=>$total]);
            }
        }else{
            return redirect('/landing');
        }
    }
    
    
    //datadiri
    public function datapelanggan(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        
        $pelanggan = DB::table('pelanggan')->where('id',$request->session()->get('id'))->first();
        return view('pelanggan2/datapelanggan',['pelanggan'=>$pelanggan]);
    }

    //transaksi
    public function datatransaksi(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $transaksi = DB::table('jenis_laundry')
            ->join('transaksi',function($join){
                $join->on('transaksi.id_Jenislaundry','=','jenis_laundry.id');
            }) 
            ->select(DB::raw('transaksi.id as id_Transaksi, id_Pelanggan, id_Admin ,Tgl_masuk, Tgl_selesai, StatusTransaksi, floor(berat*harga/1000) as harga'))
            ->where('transaksi.id_pelanggan','=',$request->session()->get('id'))
            ->get();
        $pelanggan = DB::table('pelanggan')->where('id',$request->session()->get('id'))->first();
        return view('pelanggan2/datatransaksi',['transaksi'=>$transaksi, 'pelanggan'=>$pelanggan]);
    }
    
    public function detailtransaksi(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $pelanggan = DB::table('pelanggan')
            ->join('transaksi',function($join){
                $join->on('transaksi.id_Pelanggan','=','pelanggan.id');
            })
            ->where('transaksi.id',$id)
            ->get();

        $transaksi = DB::table('transaksi')
            ->join('jenis_laundry',function($join){
                $join->on('transaksi.id_Jenislaundry','=','jenis_laundry.id');
            })
            ->select(DB::raw('transaksi.id as id_Transaksi,id_jenisLaundry, NamaPaket, berat, floor((berat/1000)*harga) as harga'))
            ->where('transaksi.id',$id)
            ->get();
        return view('pelanggan2/detailtransaksi',['transaksi'=>$transaksi, 'pelanggan'=>$pelanggan]);
    }

    public function editpelanggan(Request $request, $id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'||$request->session()->get('id')!=$id){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $pelanggan=DB::table('Pelanggan')->where('id',$id)->first();
        return view('pelanggan2/editpelanggan',['pelanggan'=>$pelanggan]);
    }

    public function updatepelanggan(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        DB::table('Pelanggan')->where('id',$request->id)->update([
            'nama' => $request->nama,
            'alamat' => $request->alamat,
            'nohp' => $request->nohp,
            'uname' => $request->uname,
            'pass' => $request->pass,
            'totalpoint' => $request->totalpoint
        ]);
        return redirect('/pelanggan/datapelanggan');
    }
    
    public function tambahtertukar(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $pelanggan = DB::table('pelanggan')->where('id',$request->session()->get('id'))->first();
        return view('/pelanggan2/tambahtertukar',['pelanggan'=>$pelanggan]);
    }

    public function inserttertukar(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        $imageName = time().'.'.$request->image->extension();  
        $request->image->move(public_path('images'), $imageName);
        DB::table('pakaiantertukar')->insert([
            'id_Pelanggan' => $request->session()->get('id'),
            'id_Transaksi' => $request->id_Transaksi,
            'deskripsi' => $imageName
        ]);
        
        return redirect('/pelanggan');
    }

    public function datatertukar(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='pelanggan'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $tertukar = DB::table('pakaiantertukar')
            ->get();
        $pelanggan = DB::table('pelanggan')->where('id',$request->session()->get('id'))->first();
        return view('pelanggan2/datatertukar',['tertukar'=>$tertukar,'pelanggan'=>$pelanggan]);
    }
    
}
