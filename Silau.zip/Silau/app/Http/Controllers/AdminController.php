<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
/* SESSION CHECK
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
*/
    public function index(Request $request){
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
            else{                
                //codestarthere
                $year=date('Y');
                $month=date('m');
                $annual = DB::table('jenis_laundry')
                    ->join('transaksi',function($join){
                        $join->on('transaksi.id_Jenislaundry','=','jenis_laundry.id');
                    }) 
                    ->whereYear('Tgl_masuk', '=', $year)
                    ->select(DB::raw('floor(sum(berat*harga/1000)) as harga'))
                    ->first();
                
                $monthly = DB::table('jenis_laundry')
                    ->join('transaksi',function($join){
                        $join->on('transaksi.id_Jenislaundry','=','jenis_laundry.id');
                    }) 
                    ->whereMonth('Tgl_masuk', $month)
                    ->select(DB::raw('floor(sum(berat*harga/1000)) as harga'))
                    ->first();
                
                $total = DB::table('transaksi')->select(DB::raw('count(id) as total'))->first();
                $pelanggan = DB::table('pelanggan')->select(DB::raw('count(id) as total'))->first();
                $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
                return view('admin2/master',['admin'=>$admin, 'annual'=>$annual, 'monthly'=>$monthly, 'total'=>$total, 'pelanggan'=>$pelanggan]);
            }
        }else{
            return redirect('/landing');
        }
    }
//PELANGGAN
    public function datapelanggan(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $pelanggan = DB::table('Pelanggan')->get();
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        return view('admin2/datapelanggan',['admin'=>$admin, 'pelanggan'=>$pelanggan]);
    }

    public function tambahpelanggan(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        return view('admin2/tambahpelanggan',['admin'=>$admin]);
    }

    public function insertpelanggan(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        DB::table('Pelanggan')->insert([
            'nama' => $request->nama,
            'alamat' => $request->alamat,
            'nohp' => $request->nohp,
            'uname' => $request->uname,
            'pass' => $request->pass,
            'totalpoint' => $request->totalpoint
        ]);
        return redirect('/admin/datapelanggan');
    }

    public function editpelanggan(Request $request, $id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        $pelanggan=DB::table('Pelanggan')->where('id',$id)->get();
        return view('admin2/editpelanggan',['admin'=>$admin,'pelanggan'=>$pelanggan]);
    }

    public function updatepelanggan(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        DB::table('Pelanggan')->where('id',$request->id)->update([
            'nama' => $request->nama,
            'alamat' => $request->alamat,
            'nohp' => $request->nohp,
            'uname' => $request->uname,
            'pass' => $request->pass,
            'totalpoint' => $request->totalpoint
        ]);
        return redirect('/admin/datapelanggan');
    }

    public function hapuspelanggan(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $pelanggan=DB::table('Pelanggan')->where('id',$id)->delete();
        return redirect('/admin/datapelanggan');
    }
//PaketLaundry
    public function datapaket(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $paket = DB::table('jenis_laundry')->get();
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        return view('admin2/datapaket',['admin'=>$admin,'paket'=>$paket]);
    }

    public function tambahpaket(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        return view('admin2/tambahpaket',['admin'=>$admin]);
    }

    public function insertpaket(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        DB::table('jenis_laundry')->insert([
            'NamaPaket' => $request->NamaPaket,
            'deskripsi' => $request->deskripsi,
            'harga' => $request->harga,
            'PointDidapat' => $request->PointDidapat,
        ]);
        return redirect('/admin/datapaket');
    }
    public function editpaket(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $paket=DB::table('jenis_laundry')->where('id',$id)->get();
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        return view('admin2/editpaket',['admin'=>$admin,'paket'=>$paket]);
    }
    public function updatepaket(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        DB::table('jenis_laundry')->where('id',$request->id)->update([
            'NamaPaket' => $request->NamaPaket,
            'deskripsi' => $request->deskripsi,
            'harga' => $request->harga,
            'PointDidapat' => $request->PointDidapat,
        ]);
        return redirect('/admin/datapaket');
    }

    public function hapuspaket(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $paket=DB::table('jenis_laundry')->where('id',$id)->delete();
        return redirect('/admin/datapaket');
    }
//transaksi
    public function datatransaksi(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $transaksi = DB::table('jenis_laundry')
            ->join('transaksi',function($join){
                $join->on('transaksi.id_Jenislaundry','=','jenis_laundry.id');
            }) 
            ->select(DB::raw('transaksi.id as id_Transaksi, id_Pelanggan, id_Admin ,Tgl_masuk, Tgl_selesai, StatusTransaksi, floor(berat*harga/1000) as harga'))
            ->get();
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        return view('admin2/datatransaksi',['admin'=>$admin,'transaksi'=>$transaksi]);
    }
    public function detailtransaksi(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $pelanggan = DB::table('pelanggan')
            ->join('transaksi',function($join){
                $join->on('transaksi.id_Pelanggan','=','pelanggan.id');
            })
            ->where('transaksi.id',$id)
            ->get();

        $transaksi = DB::table('transaksi')
            ->join('jenis_laundry',function($join){
                $join->on('transaksi.id_Jenislaundry','=','jenis_laundry.id');
            })
            ->select(DB::raw('transaksi.id as id_Transaksi,id_jenisLaundry, NamaPaket, berat, floor((berat/1000)*harga) as harga'))
            ->where('transaksi.id',$id)
            ->get();
        return view('admin2/detailtransaksi',['transaksi'=>$transaksi, 'pelanggan'=>$pelanggan]);
    }

    public function tambahtransaksi(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $nextid = DB::table('Transaksi')
            ->select(DB::raw('MAX(id)+1 as id'))
            ->first();
        
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        $tanggal=date("Y-m-d");
        $paket=DB::table('Jenis_Laundry')->get();
        return view('admin2/tambahtransaksi',['admin'=>$admin,'tanggal'=>$tanggal,'nextid'=>$nextid, 'paket'=>$paket]);
    }

    public function inserttransaksi(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $date=date("Y-m-d");
        DB::table('transaksi')->insert([
            'id' => $request->id,
            'id_Pelanggan' => $request->id_pelanggan,
            'id_Admin' => $request->id_admin,
            'Tgl_masuk' => $date,
            'id_jenisLaundry' => $request->id_paket,
            'berat' => $request->berat,
            'StatusTransaksi' => 0,
        ]);
        return redirect('/admin/datatransaksi');
    }
/*
    public function edittransaksi(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $transaksi=DB::table('transaksi')->where('id',$id)->get();

        return view('admin/edittransaksi',['transaksi'=>$transaksi]);
    }
    public function updatetransaksi(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        DB::table('transaksi')->where('id',$request->id)->update([
            'Namatransaksi' => $request->Namatransaksi,
            'deskripsi' => $request->deskripsi,
            'harga' => $request->harga,
            'PointDidapat' => $request->PointDidapat,
        ]);
        return redirect('/admin/datatransaksi');
    }
*/
    
    public function bayartransaksi(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $currentstatus=DB::table('transaksi')->where('id',$request->id)->select(DB::raw('statustransaksi'))->first();
        if($currentstatus->statustransaksi==0){
            $transaksi = DB::table('jenis_laundry')
                ->join('transaksi',function($join){
                    $join->on('transaksi.id_Jenislaundry','=','jenis_laundry.id');
                }) 
                ->where('transaksi.id',$request->id)
                ->select(DB::raw('PointDidapat'))
                ->first();
            $pointpelanggan = DB::table('pelanggan')
                ->join('transaksi',function($join){
                    $join->on('transaksi.id_Pelanggan','=','pelanggan.id');
                }) 
                ->where('transaksi.id',$request->id)
                ->select(DB::raw('totalpoint, pelanggan.id'))
                ->first();
            $total=$pointpelanggan->totalpoint+$transaksi->PointDidapat;
            DB::table('pelanggan')->where('id',$pointpelanggan->id)->update([
                'totalpoint' => $total,
            ]);
        }
        $status = 1;
        DB::table('transaksi')->where('id',$request->id)->update([
            'StatusTransaksi' => $status,
        ]);
        return redirect('/admin/datatransaksi');
    }

    public function selesaitransaksi(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $date=date("Y-m-d");
        DB::table('transaksi')->where('id',$request->id)->update([
            'Tgl_Selesai' => $date,
        ]);
        return redirect('/admin/datatransaksi');
    }

    public function hapustransaksi(Request $request,$id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $transaksi=DB::table('transaksi')->where('id',$id)->delete();
        return redirect('/admin/datatransaksi');
    }
    //bajutertukar
    
    public function datatertukar(Request $request){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $tertukar = DB::table('pakaiantertukar')
            ->get();
        $admin = DB::table('admin')->where('id',$request->session()->get('id'))->first();
        return view('admin2/datatertukar',['tertukar'=>$tertukar,'admin'=>$admin]);
    }

    public function hapustertukar(Request $request, $id){
        
        if($request->session()->has('id')){
            if($request->session()->get('usertype')!='admin'){
                return redirect('/landing');
            }
        }else{
            return redirect('/landing');
        }
        //codestarthere
        $tertukar=DB::table('pakaiantertukar')->where('id',$id)->delete();
        return redirect('/admin/datatertukar');
    }
}
