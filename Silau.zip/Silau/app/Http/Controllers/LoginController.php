<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    public function index(Request $request){
        return view('login');
    }
    
    public function proses(Request $request){
        $login = DB::table('Pelanggan')->where('uname',$request->uname)->first();
        if($login!=NULL){
            if($login->pass==$request->pass){
                $request->session()->put('id',$login->id);
                $request->session()->put('usertype','pelanggan');
                return redirect('/pelanggan');
            }
            else{
                return redirect('/login');
            }
        }
        $login = DB::table('admin')->where('uname',$request->uname)->first();
		if($login!=NULL){
            if($login->pass==$request->pass){
                $request->session()->put('id',$login->id);
                $request->session()->put('usertype','admin');
                return redirect('/admin');
            }
            else{
                return redirect('/login');
            }
        }else{
            return redirect('/login');
        }
    }

    public function logout(Request $request){
		$request->session()->forget('id');
        return redirect('/login');
    }

    public function landing(Request $request){
		if($request->session()->has('id')){
            if($request->session()->get('usertype')=='admin'){
                return redirect('/admin');    
            }
            else if($request->session()->get('usertype')=='pelanggan'){
                return redirect('/pelanggan');    
            }
            else{
                return redirect('/logout');
            }
        }else{
            return redirect('/login');
        }
    }
/*LOGIN DUMMY//
    public function dummy(Request $request){
        $request->session()->put('id','1');
        $request->session()->put('usertype','random');
        return redirect('/admin');
    }
*/  
}