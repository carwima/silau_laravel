<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Detail Transaksi</h3>
	
	<br/>
	
	<?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p>
	Nama : <?php echo e($p->nama); ?> <br/>
	ID Transaksi : <?php echo e($p->id); ?> <br/>
	Tanggal Masuk : <?php echo e($p->Tgl_masuk); ?><br/>
	Tanggal Selesai : <?php echo e($p->Tgl_selesai); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<table border="1">
		<tr>
			<th>Jenis Paket</th>
			<th>Berat</th>
			<th>Harga</th>
		</tr>
		<?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($t->NamaPaket); ?></td>
			<td><?php echo e($t->berat); ?></td>
			<td><?php echo e($t->harga); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	
	<a href="/admin/datatransaksi">kembali</a>


</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin/detailtransaksi.blade.php ENDPATH**/ ?>