<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('admin2.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php echo $__env->make('admin2.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      <?php echo $__env->make('admin2.partials.topnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Pelanggan</h1></div>
        
	    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <form action="simpan" method="post">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
            <input type="hidden" name="id" value="<?php echo e($p->id); ?>"> <br/>
            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" name="nama" placeholder="Nama"  value="<?php echo e($p->nama); ?>">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" class="form-control" name="alamat" placeholder="Alamat"  value="<?php echo e($p->alamat); ?>">
            </div>
            <div class="form-group">
                <label for="nohp">No HP</label>
                <input type="text" class="form-control" name="nohp" placeholder="No HP" value="<?php echo e($p->nohp); ?>">
            </div>
            <div class="form-group">
                <label for="nohp">Username</label>
                <input type="text" class="form-control" name="uname" placeholder="Username" value="<?php echo e($p->uname); ?>">
            </div>
            <div class="form-group">
                <label for="pass">Password</label>
                <input type="password" class="form-control" name="pass" placeholder="Password" value="<?php echo e($p->pass); ?>">
            </div>
            <input type="hidden" name="totalpoint" value="<?php echo e($p->totalpoint); ?>"> <br/>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    <?php echo $__env->make('admin2.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php echo $__env->make('admin2.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin2/editpelanggan.blade.php ENDPATH**/ ?>