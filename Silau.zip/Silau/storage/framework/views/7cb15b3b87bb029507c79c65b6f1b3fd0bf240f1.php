<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
  <div class="sidebar-brand-icon rotate-n-15">
    <i class="fas fa-tshirt"></i>
  </div>
  <div class="sidebar-brand-text mx-3">Silau<sup>1</sup></div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
  <a class="nav-link" href="/admin">
    <i class="fas fa-fw fa-tachometer-alt"></i>
    <span>Dashboard</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
  Laundry
</div>

<!-- Transaksi Laundry -->
<li class="nav-item">
  <a class="nav-link" href="/admin/datatransaksi">
    <i class="fas fa-fw fa-table"></i>
    <span>Transaksi Laundry</span></a>
</li>

<!-- Paket Laundry -->
<li class="nav-item">
  <a class="nav-link" href="/admin/datapaket">
    <i class="fas fa-fw fa-table"></i>
    <span>Paket Laundry</span></a>
</li>

<!-- Pakaian Tertukar -->
<li class="nav-item">
  <a class="nav-link" href="/admin/datatertukar">
    <i class="fas fa-fw fa-table"></i>
    <span>Pakaian Tertukar</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
  Pelanggan
</div>

<!-- Pelanggan -->
<li class="nav-item">
  <a class="nav-link" href="/admin/datapelanggan">
    <i class="fas fa-fw fa-table"></i>
    <span>Pelanggan</span></a>
</li>


<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
  <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar --><?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin2/partials/sidebar.blade.php ENDPATH**/ ?>