<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Tambah Paket</h3>
	<a href="/admin/datapaket">Kembali</a>
	<br/>
	<form action="tambahpaket/simpan" method="post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">

      	Nama Paket :
		<input type="text" name="NamaPaket"> <br/>
		Deskripsi :
		<input type="text" name="deskripsi"> <br/>
		Harga :
		<input type="text" name="harga"> <br/>
		Point Didapat :
		<input type="text" name="PointDidapat"> <br/>
		<input type="submit" value="Simpan">
	</form>

</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin/tambahpaket.blade.php ENDPATH**/ ?>