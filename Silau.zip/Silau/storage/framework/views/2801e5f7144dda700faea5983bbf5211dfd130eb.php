<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Tambah Paket</h3>
	<a href="/pelanggan">Kembali</a>
	<br/>
	<form action="tambahtertukar/simpan" method="post" enctype="multipart/form-data">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
      	ID Transaksi :
		<input type="text" name="id_Transaksi"> <br/>
		Deskripsi :
        <input type="file" name="image" class="form-control"><br/>
		<input type="submit" value="Simpan">
	</form>

</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views//pelanggan/tambahtertukar.blade.php ENDPATH**/ ?>