<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('pelanggan2.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php echo $__env->make('pelanggan2.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      <?php echo $__env->make('pelanggan2.partials.topnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Diri</h1></div>
        
          <form>
            <div class="form-group">
                <label for="nama">ID</label>
                <input type="text" class="form-control" name="nama" placeholder="Nama"  value="<?php echo e($pelanggan->id); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" name="nama" placeholder="Nama"  value="<?php echo e($pelanggan->nama); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" class="form-control" name="alamat" placeholder="Alamat"  value="<?php echo e($pelanggan->alamat); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="nohp">No HP</label>
                <input type="text" class="form-control" name="nohp" placeholder="No HP" value="<?php echo e($pelanggan->nohp); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="nohp">Username</label>
                <input type="text" class="form-control" name="uname" placeholder="Username" value="<?php echo e($pelanggan->uname); ?>" disabled>
            </div>
            <a href="/pelanggan/editpelanggan/<?php echo e($pelanggan->id); ?>" class="btn btn-primary">Edit</a>
          </form>
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    <?php echo $__env->make('pelanggan2.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php echo $__env->make('pelanggan2.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Silau\resources\views/pelanggan2/datapelanggan.blade.php ENDPATH**/ ?>