<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h1>Halaman Pelanggan</h1>

	<br>


	<a href="/pelanggan/datapelanggan">Data Pelanggan</a><br/>
	<a href="/pelanggan/review">Review Kamu</a><br/>
	<a href="/pelanggan/datatransaksi">Transaksi Laundry</a><br/>
	<a href="/pelanggan/bajutertukar">Baju Tertukar</a><br/>
	<a href="/logout">Logout</a><br/>
	<h3>Data Pelanggan</h3>
	
	<br/>
	<br/>

	<table border="1">
		Nama : <?php echo e($pelanggan->nama); ?> <br/>
		Alamat : <?php echo e($pelanggan->alamat); ?> <br/>
		Handphone : <?php echo e($pelanggan->nohp); ?> <br/>
		Point Dimiliki : <?php echo e($pelanggan->totalpoint); ?> <br/>
		<a href="/pelanggan/editpelanggan/<?php echo e($pelanggan->id); ?>">Edit</a>

	</table>
	<a href="/pelanggan">kembali</a>


</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/pelanggan/datapelanggan.blade.php ENDPATH**/ ?>