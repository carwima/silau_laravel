<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Edit Pelanggan</h3>

	<a href="/admin/datapelanggan">Kembali</a>
	<br/>
	<?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="simpan" method="post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
		<input type="hidden" name="id" value="<?php echo e($p->id); ?>"> <br/>
      	Nama :
		<input type="text" name="nama" value="<?php echo e($p->nama); ?>"> <br/>
		Alamat :
		<input type="text" name="alamat" value="<?php echo e($p->alamat); ?>"> <br/>
		No HP :
		<input type="text" name="nohp" value="<?php echo e($p->nohp); ?>"> <br/>
		Username :
		<input type="text" name="uname" value="<?php echo e($p->uname); ?>"> <br/>
		Password :
		<input type="text" name="pass" value="<?php echo e($p->pass); ?>"> <br/>
		<input type="hidden" name="totalpoint" value="0"> <br/>
		<input type="submit" value="Simpan">
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/pelanggan/editpelanggan.blade.php ENDPATH**/ ?>