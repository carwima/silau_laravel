<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('admin2.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php echo $__env->make('admin2.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      <?php echo $__env->make('admin2.partials.topnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Transaksi Baru</h1></div>
          <form action="tambahtransaksi/simpan" method="post">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
            <div class="form-group">
                <label for="id">ID Transaksi</label>
                <input type="text" class="form-control" value="<?php echo e($nextid->id); ?>" disabled>
                <input type="hidden" class="form-control" name="id" value="<?php echo e($nextid->id); ?>" placeholder="ID_Transaksi">
            </div>
            <div class="form-group">
                <label for="id_pelanggan">ID Pelanggan</label>
                <input type="text" class="form-control" name="id_pelanggan" placeholder="ID Pelanggan">
            </div>
            <div class="form-group">
                <label for="id_admin">ID Admin</label>
                <input type="text" class="form-control" value="<?php echo e($admin->id); ?>" disabled>
                <input type="hidden" class="form-control" name="id_admin" value="<?php echo e($admin->id); ?>" placeholder="ID_Transaksi">
            </div>
            <div class="form-group">
                <label for="Tgl_masuk">Tanggal masuk</label>
                <input type="text" class="form-control" value="<?php echo e($tanggal); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="paket">Paket Dipilih</label>
                <select class="form-control" name="id_paket">
                    <?php $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->NamaPaket); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br/>
            </div>
            <div class="form-group">
                <label for="berat">Berat(gram)</label>
                <input type="text" class="form-control" name="berat" placeholder="Berat Cucian">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    <?php echo $__env->make('admin2.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php echo $__env->make('admin2.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin2/tambahtransaksi.blade.php ENDPATH**/ ?>