<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	
	<h1>Halaman Admin</h1>

	<br>

	<a href="/admin/datapelanggan">Data Pelanggan</a>
	<br/>
	<a href="/admin/datapaket">Paket Laundry</a>
	<br/>
	<a href="/admin/datatransaksi">Transaksi Laundry</a>
	<br/>
	<a href="/logout">Logout</a>

	<h3>Data Transaksi</h3>

	<a href="tambahtransaksi"> + Transaksi Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>ID Transaksi </th>
			<th>ID Pelanggan</th>
			<th>ID Admin</th>
			<th>Tanggal Masuk</th>
			<th>Tanggal Selesai</th>
			<th>Status</th>
			<th>Harga</th>
			<th>Action</th>
		</tr>
		<?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($t->id_Transaksi); ?></td>
			<td><?php echo e($t->id_Pelanggan); ?></td>
			<td><?php echo e($t->id_Admin); ?></td>
			<td><?php echo e($t->Tgl_masuk); ?></td>
			<?php if($t->Tgl_selesai==NULL): ?>{
				<td>Belum Selesai</td>
			}<?php else: ?>{
				<td><?php echo e($t->Tgl_selesai); ?></td>
			}
			<?php endif; ?>
			<?php if($t->StatusTransaksi==1): ?>{
				<td>Selesai.</td>
			}<?php else: ?>{
				<td>Proses.</td>
			}
			<?php endif; ?>
			<td><?php echo e($t->harga); ?></td>
			<td>
				<a href="/admin/detailtransaksi/<?php echo e($t->id_Transaksi); ?>">Details</a>
				|
				<a href="/admin/selesaitransaksi/<?php echo e($t->id_Transaksi); ?>">Selesai</a>
				|
				<a href="/admin/bayartransaksi/<?php echo e($t->id_Transaksi); ?>">Bayar</a>
				|
				<a href="/admin/hapustransaksi/<?php echo e($t->id_Transaksi); ?>">Hapus</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	
	<a href="/admin">kembali</a>


</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin/datatransaksi.blade.php ENDPATH**/ ?>