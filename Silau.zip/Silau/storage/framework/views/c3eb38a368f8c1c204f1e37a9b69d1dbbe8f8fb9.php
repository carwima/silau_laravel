<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('pelanggan2.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php echo $__env->make('pelanggan2.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      <?php echo $__env->make('pelanggan2.partials.topnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Laporan pakaian tertukar</h1></div>
          <form action="tambahtertukar/simpan" method="post" enctype="multipart/form-data">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
            <div class="form-group">
                <label for="id_Transaksi">ID Transaksi</label>
                <input type="text" class="form-control" name="id_Transaksi" placeholder="ID Transaksi">
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <input type="file" name="image" class="form-control"><br/>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    <?php echo $__env->make('pelanggan2.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php echo $__env->make('pelanggan2.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Silau\resources\views//pelanggan2/tambahtertukar.blade.php ENDPATH**/ ?>