<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Tambah Transaksi</h3>
	<a href="/admin/datatransaksi">Kembali</a>
	<br/>
	ID Transaksi : <?php echo e($nextid->id); ?>

	<form action="tambahtransaksi/simpan" method="post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
		<input type="hidden" name="id" value="<?php echo e($nextid->id); ?>"> 
		ID Pelanggan :
		<input type="text" name="id_pelanggan" required> <br/>
		ID Admin : <?php echo e($admin); ?>

		<input type="hidden" name="id_admin" value='<?php echo e($admin); ?>'> <br/>
		Tanggal masuk : <?php echo e($tanggal); ?><br>
		Paket yang dipilih :
		<select name="id_paket">
			<?php $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($p->id); ?>"><?php echo e($p->NamaPaket); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select><br/>
		Berat :
		<input type="text" name="berat"  required> <br/>
		<input type="submit" value="Simpan">
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin/tambahtransaksi.blade.php ENDPATH**/ ?>