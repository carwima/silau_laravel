<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h1>Halaman Admin</h1>

	<br>


	<a href="/admin/datapelanggan">Data Pelanggan</a>
	<br/>
	<a href="/admin/datapaket">Paket Laundry</a>
	<br/>
	<a href="/admin/datatransaksi">Transaksi Laundry</a>
	<br/>
	<a href="/admin/datatertukar">Baju Tertukar</a>
	<br/>
	<a href="/logout">Logout</a>
	<h3>Data Pelanggan</h3>

	<a href="tambahpelanggan"> + Tambah Pelanggan Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>nama</th>
			<th>alamat</th>
			<th>nohp</th>
			<th>totalpoint</th>
		</tr>
		<?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($p->nama); ?></td>
			<td><?php echo e($p->alamat); ?></td>
			<td><?php echo e($p->nohp); ?></td>
			<td><?php echo e($p->totalpoint); ?></td>
			<td>
				<a href="/admin/editpelanggan/<?php echo e($p->id); ?>">Edit</a>
				|
				<a href="/admin/hapus/<?php echo e($p->id); ?>">Hapus</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="/admin">kembali</a>


</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin/datapelanggan.blade.php ENDPATH**/ ?>