<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>

	<h1>Admin Landing</h1>

	<br>

	<p>Nama : <?php echo e($admin->pass); ?></p>

	<a href="admin/datapelanggan">Data Pelanggan</a>
	<br/>
	<a href="admin/datapaket">Paket Laundry</a>
	<br/>
	<a href="admin/datatransaksi">Transaksi Laundry</a>
	<br/>
	<a href="/logout">Logout</a>


</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin/landing.blade.php ENDPATH**/ ?>