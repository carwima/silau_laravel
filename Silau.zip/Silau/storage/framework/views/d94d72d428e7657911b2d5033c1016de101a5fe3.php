<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
	<style>
		.boxed {
  			text-align: center;
			border: 1px solid black ;
			width:200px;
		} 
		table{
			margin: 0 auto;
		}
	</style>
</head>
<body>
	<div class="boxed">
		<h3>== SILAU ==</h3>
		<h3>Struck Pengambilan Cucian</h3>
		<?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		Nama : <?php echo e($p->nama); ?> <br/>
		ID Transaksi : <?php echo e($p->id); ?> <br/>
		Tanggal Masuk : <?php echo e($p->Tgl_masuk); ?><br/>
		Tanggal Selesai : <?php echo e($p->Tgl_selesai); ?><br/>
		.
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<table border="1">
			<tr>
				<th>Jenis Paket</th>
				<th>Berat</th>
				<th>Harga</th>
			</tr>
			<?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($t->NamaPaket); ?></td>
				<td><?php echo e($t->berat); ?></td>
				<td><?php echo e($t->harga); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
		.<br/>
		Harap ditunjukkan saat pengambilan.<br/>
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/pelanggan2/detailtransaksi.blade.php ENDPATH**/ ?>