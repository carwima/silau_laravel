<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	
	<h1>Halaman Admin</h1>

	<br>

	
	<a href="/pelanggan/datapelanggan">Data Pelanggan</a><br/>
	<a href="/pelanggan/review">Paket Laundry</a><br/>
	<a href="/pelanggan/datatransaksi">Transaksi Laundry</a><br/>
	<a href="/logout">Logout</a><br/>

	<h3>Data Transaksi</h3>

	<table border="1">
		<tr>
			<th>ID Transaksi </th>	
			<th>ID Admin</th>
			<th>Tanggal Masuk</th>
			<th>Status</th>
			<th>Harga</th>
			<th>Action</th>
		</tr>
		<?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($t->id_Transaksi); ?></td>
			<td><?php echo e($t->id_Admin); ?></td>
			<td><?php echo e($t->Tgl_masuk); ?></td>
			<?php if($t->StatusTransaksi==1): ?>
				<td>Selesai.</td>
			<?php else: ?>
				<td>Proses.</td>
			<?php endif; ?>
			<td><?php echo e($t->harga); ?></td>
			<td>
				<a href="/pelanggan/detailtransaksi/<?php echo e($t->id_Transaksi); ?>">Details</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	
	<a href="/pelanggan">kembali</a>


</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/pelanggan/datatransaksi.blade.php ENDPATH**/ ?>