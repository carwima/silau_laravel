<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Edit Paket</h3>

	<a href="/admin/datapaket">Kembali</a>
	<br/>
	<?php $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="simpan" method="post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
		<input type="hidden" name="id" value="<?php echo e($p->id); ?>"> <br/>
      	Nama Paket :
		<input type="text" name="NamaPaket" value="<?php echo e($p->NamaPaket); ?>"> <br/>
		Deskripsi :
		<input type="text" name="deskripsi" value="<?php echo e($p->deskripsi); ?>"> <br/>
		Harga (per KG) :
		<input type="text" name="harga" value="<?php echo e($p->harga); ?>"> <br/>
		Point Didapat(Per KG) :
		<input type="text" name="PointDidapat" value="<?php echo e($p->PointDidapat); ?>"> <br/>
		<input type="submit" value="Simpan">
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/admin/editpaket.blade.php ENDPATH**/ ?>