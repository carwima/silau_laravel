<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Login</h3>
	<br/>
	<form action="login/proses" method="post" autocomplete="off">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
      	Username :
		<input type="text" name="uname"> <br/>
		Password :
		<input type="password" name="pass"> <br/>
		<input type="submit" value="Login">
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\Silau\resources\views/login/login.blade.php ENDPATH**/ ?>