<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//login
Route::get('login','LoginController@index');
Route::post('login/proses','LoginController@proses');
Route::get('logout','LoginController@logout');
//landing
Route::get('landing','LoginController@landing');
//Route::get('admin/dummy', 'LoginController@dummy');

//admin
Route::get('admin', 'AdminController@index');
//CRUDpelanggan
Route::get('admin/datapelanggan', 'AdminController@datapelanggan');
Route::get('admin/tambahpelanggan', 'AdminController@tambahpelanggan');
Route::post('admin/tambahpelanggan/simpan', 'AdminController@insertpelanggan');
Route::get('admin/editpelanggan/{id}','AdminController@editpelanggan');
Route::post('admin/editpelanggan/simpan','AdminController@updatepelanggan');
Route::get('admin/hapuspelanggan/{id}', 'AdminController@hapuspelanggan');
//paket laundry
Route::get('admin/datapaket', 'AdminController@datapaket');
Route::get('admin/tambahpaket', 'AdminController@tambahpaket');
Route::post('admin/tambahpaket/simpan', 'AdminController@insertpaket');
Route::get('admin/editpaket/{id}','AdminController@editpaket');
Route::post('admin/editpaket/simpan','AdminController@updatepaket');
Route::get('admin/hapuspaket/{id}', 'AdminController@hapuspaket');

//transaksi
Route::get('admin/datatransaksi', 'AdminController@datatransaksi'); //show
Route::get('admin/detailtransaksi/{id}', 'AdminController@detailtransaksi'); //show
Route::get('admin/detailtransaksi/edit/{id}', 'AdminController@editdetailtransaksi'); //show
Route::get('admin/tambahtransaksi', 'AdminController@tambahtransaksi'); //create
Route::post('admin/tambahtransaksi/simpan', 'AdminController@inserttransaksi');//create
Route::get('admin/hapustransaksi/{id}', 'AdminController@hapustransaksi'); //delete
Route::get('admin/hapustertukar/{id}', 'AdminController@hapustertukar'); //delete
Route::get('admin/bayartransaksi/{id}', 'AdminController@bayartransaksi'); //update-selesai
Route::get('admin/selesaitransaksi/{id}', 'AdminController@selesaitransaksi'); //update-selesai

//tertukar
Route::get('admin/datatertukar', 'AdminController@datatertukar');
//pelanggan
Route::get('pelanggan', 'PelangganController@index');
Route::get('pelanggan/datatransaksi', 'PelangganController@datatransaksi');
Route::get('pelanggan/detailtransaksi/{id}', 'PelangganController@detailtransaksi'); //show
Route::get('pelanggan/datapelanggan', 'PelangganController@datapelanggan');
Route::get('pelanggan/editpelanggan/{id}', 'PelangganController@editpelanggan');
Route::post('pelanggan/editpelanggan/simpan', 'PelangganController@updatepelanggan');
Route::get('pelanggan/datatertukar', 'PelangganController@datatertukar');
Route::get('pelanggan/tambahtertukar', 'PelangganController@tambahtertukar');
Route::post('pelanggan/tambahtertukar/simpan', 'PelangganController@inserttertukar');

//image upload
Route::get('imageupload', 'ImageController@imageUpload')->name('image.upload');
Route::post('imageupload', 'ImageController@imageUploadPost')->name('image.upload.post');
//bootstraptest
Route::view('bootstrap','pelanggan2/datapelanggan');