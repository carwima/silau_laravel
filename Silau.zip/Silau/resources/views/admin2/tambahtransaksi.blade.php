<!DOCTYPE html>
<html lang="en">

@include('admin2.partials.head')
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    @include('admin2.partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      @include('admin2.partials.topnavbar')

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Transaksi Baru</h1></div>
          <form action="tambahtransaksi/simpan" method="post">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
            <div class="form-group">
                <label for="id">ID Transaksi</label>
                <input type="text" class="form-control" value="{{$nextid->id}}" disabled>
                <input type="hidden" class="form-control" name="id" value="{{$nextid->id}}" placeholder="ID_Transaksi">
            </div>
            <div class="form-group">
                <label for="id_pelanggan">ID Pelanggan</label>
                <input type="text" class="form-control" name="id_pelanggan" placeholder="ID Pelanggan">
            </div>
            <div class="form-group">
                <label for="id_admin">ID Admin</label>
                <input type="text" class="form-control" value="{{$admin->id}}" disabled>
                <input type="hidden" class="form-control" name="id_admin" value="{{$admin->id}}" placeholder="ID_Transaksi">
            </div>
            <div class="form-group">
                <label for="Tgl_masuk">Tanggal masuk</label>
                <input type="text" class="form-control" value="{{$tanggal}}" disabled>
            </div>
            <div class="form-group">
                <label for="paket">Paket Dipilih</label>
                <select class="form-control" name="id_paket">
                    @foreach($paket as $p)
                    <option value="{{$p->id}}">{{$p->NamaPaket}}</option>
                    @endforeach
                </select><br/>
            </div>
            <div class="form-group">
                <label for="berat">Berat(gram)</label>
                <input type="text" class="form-control" name="berat" placeholder="Berat Cucian">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    @include('admin2.partials.footer')
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  @include('admin2.partials.scripts')
</body>
</html>
