<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
	<style>
		.boxed {
  			text-align: center;
			border: 1px solid black ;
			width:200px;
		} 
		table{
			margin: 0 auto;
		}
	</style>
</head>
<body>
	<div class="boxed">
		<h3>== SILAU ==</h3>
		<h3>Struck Pengambilan Cucian</h3>
		@foreach($pelanggan as $p)
		Nama : {{$p->nama}} <br/>
		ID Transaksi : {{$p->id}} <br/>
		Tanggal Masuk : {{$p->Tgl_masuk}}<br/>
		Tanggal Selesai : {{$p->Tgl_selesai}}<br/>
		.
		@endforeach
		<table border="1">
			<tr>
				<th>Jenis Paket</th>
				<th>Berat</th>
				<th>Harga</th>
			</tr>
			@foreach($transaksi as $t)
			<tr>
				<td>{{ $t->NamaPaket }}</td>
				<td>{{ $t->berat }}</td>
				<td>{{ $t->harga }}</td>
			</tr>
			@endforeach
		</table>
		.<br/>
		Harap ditunjukkan saat pengambilan.<br/>
	</div>
</body>
</html>