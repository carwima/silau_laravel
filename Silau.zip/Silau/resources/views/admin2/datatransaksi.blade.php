<!DOCTYPE html>
<html lang="en">

@include('admin2.partials.head')

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    @include('admin2.partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        @include('admin2.partials.topnavbar')
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Data Transaksi</h1>
          <p class="mb-4">Data Transaksi SILAU</a></p>
          <a href="/admin/tambahtransaksi" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Transaksi Baru</a>


          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">List Data Transaksi</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                        <th>ID Transaksi </th>
                        <th>ID Pelanggan</th>
                        <th>ID Admin</th>
                        <th>Tanggal Masuk</th>
                        <th>Tanggal Selesai</th>
                        <th>Status</th>
                        <th>Harga</th>
                        <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                        <th>ID Transaksi </th>
                        <th>ID Pelanggan</th>
                        <th>ID Admin</th>
                        <th>Tanggal Masuk</th>
                        <th>Tanggal Selesai</th>
                        <th>Status</th>
                        <th>Harga</th>
                        <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
                  @foreach($transaksi as $t)
                    <tr>
                        <td>{{ $t->id_Transaksi }}</td>
                        <td>{{ $t->id_Pelanggan }}</td>
                        <td>{{ $t->id_Admin }}</td>
                        <td>{{ $t->Tgl_masuk }}</td>
                        @if($t->Tgl_selesai==NULL)
                            <td>Belum Selesai</td>
                        @else
                            <td>{{$t->Tgl_selesai}}</td>
                        
                        @endif
                        @if($t->StatusTransaksi==1)
                            <td>Selesai.</td>
                        @else{
                            <td>Proses.</td>
                        
                        @endif
                        <td>{{ $t->harga }}</td>
                        <td>
                            <a href="/admin/detailtransaksi/{{ $t->id_Transaksi }}">Invoice</a>
                            |
                            <a href="/admin/selesaitransaksi/{{ $t->id_Transaksi }}">Selesai</a>
                            |
                            <a href="/admin/bayartransaksi/{{ $t->id_Transaksi }}">Bayar</a>
                            |
                            <a href="/admin/hapustransaksi/{{ $t->id_Transaksi }}">Hapus</a>
                        </td>
                    </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      @include('admin2.partials.footer')

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

    @include('admin2.partials.scripts')
</body>

</html>
