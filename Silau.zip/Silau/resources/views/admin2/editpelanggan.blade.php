<!DOCTYPE html>
<html lang="en">

@include('admin2.partials.head')
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    @include('admin2.partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      @include('admin2.partials.topnavbar')

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Pelanggan</h1></div>
        
	    @foreach($pelanggan as $p)
          <form action="simpan" method="post">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
            <input type="hidden" name="id" value="{{ $p->id }}"> <br/>
            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" name="nama" placeholder="Nama"  value="{{ $p->nama }}">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" class="form-control" name="alamat" placeholder="Alamat"  value="{{ $p->alamat }}">
            </div>
            <div class="form-group">
                <label for="nohp">No HP</label>
                <input type="text" class="form-control" name="nohp" placeholder="No HP" value="{{ $p->nohp }}">
            </div>
            <div class="form-group">
                <label for="nohp">Username</label>
                <input type="text" class="form-control" name="uname" placeholder="Username" value="{{ $p->uname }}">
            </div>
            <div class="form-group">
                <label for="pass">Password</label>
                <input type="password" class="form-control" name="pass" placeholder="Password" value="{{ $p->pass }}">
            </div>
            <input type="hidden" name="totalpoint" value="{{ $p->totalpoint }}"> <br/>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        @endforeach
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    @include('admin2.partials.footer')
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  @include('admin2.partials.scripts')
</body>
</html>
