<!DOCTYPE html>
<html lang="en">

@include('admin2.partials.head')
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    @include('admin2.partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      @include('admin2.partials.topnavbar')

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Tambah Pelanggan</h1></div>
          <form action="tambahpaket/simpan" method="post">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
            <div class="form-group">
                <label for="NamaPaket">Nama Paket</label>
                <input type="text" class="form-control" name="NamaPaket" placeholder="Nama Paket">
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <input type="text" class="form-control" name="deskripsi" placeholder="Deskripsi">
            </div>
            <div class="form-group">
                <label for="harga">Harga</label>
                <input type="text" class="form-control" name="harga" placeholder="Harga">
            </div>
            <div class="form-group">
                <label for="PointDidapat">Point Didapat</label>
                <input type="text" class="form-control" name="PointDidapat" placeholder="Point Didapat">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    @include('admin2.partials.footer')
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  @include('admin2.partials.scripts')
</body>
</html>
