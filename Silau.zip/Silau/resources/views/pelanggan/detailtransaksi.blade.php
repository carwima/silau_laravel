<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Detail Transaksi Pelanggan</h3>
	
	<br/>
	
	@foreach($pelanggan as $p)
	<p>
	Nama : {{$p->nama}} <br/>
	ID Transaksi : {{$p->id}} <br/>
	Tanggal Masuk : {{$p->Tgl_masuk}}<br/>
	Tanggal Selesai : {{$p->Tgl_selesai}}
	@endforeach
	<table border="1">
		<tr>
			<th>Jenis Paket</th>
			<th>Berat</th>
			<th>Harga</th>
		</tr>
		@foreach($transaksi as $t)
		<tr>
			<td>{{ $t->NamaPaket }}</td>
			<td>{{ $t->berat }}</td>
			<td>{{ $t->harga }}</td>
		</tr>
		@endforeach
	</table>
	
	<a href="/pelanggan/datatransaksi">kembali</a>


</body>
</html>