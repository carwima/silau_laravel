<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	
	<h1>Halaman Admin</h1>

	<br>

	
	<a href="/pelanggan/datapelanggan">Data Pelanggan</a><br/>
	<a href="/pelanggan/review">Paket Laundry</a><br/>
	<a href="/pelanggan/datatransaksi">Transaksi Laundry</a><br/>
	<a href="/logout">Logout</a><br/>

	<h3>Data Transaksi</h3>

	<table border="1">
		<tr>
			<th>ID Transaksi </th>	
			<th>ID Admin</th>
			<th>Tanggal Masuk</th>
			<th>Status</th>
			<th>Harga</th>
			<th>Action</th>
		</tr>
		@foreach($transaksi as $t)
		<tr>
			<td>{{ $t->id_Transaksi }}</td>
			<td>{{ $t->id_Admin }}</td>
			<td>{{ $t->Tgl_masuk }}</td>
			@if($t->StatusTransaksi==1)
				<td>Selesai.</td>
			@else
				<td>Proses.</td>
			@endif
			<td>{{ $t->harga }}</td>
			<td>
				<a href="/pelanggan/detailtransaksi/{{ $t->id_Transaksi }}">Details</a>
			</td>
		</tr>
		@endforeach
	</table>
	
	<a href="/pelanggan">kembali</a>


</body>
</html>