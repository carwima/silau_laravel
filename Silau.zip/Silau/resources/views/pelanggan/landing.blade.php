<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>

	<h1>Pelanggan Landing</h1>

	<br>

	<p>Nama : {{ $pelanggan->nama }}</p>

	<a href="/pelanggan/datapelanggan">Data Pelanggan</a>
	<br/>
	<a href="/pelanggan/datatransaksi">Transaksi Laundry</a>
	<br/>
	<a href="/pelanggan/tambahtertukar">Baju Tertukar</a>
	<br/>
	<a href="/logout">Logout</a>


</body>
</html>