<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h1>Halaman Pelanggan</h1>

	<br>


	<a href="/pelanggan/datapelanggan">Data Pelanggan</a><br/>
	<a href="/pelanggan/review">Review Kamu</a><br/>
	<a href="/pelanggan/datatransaksi">Transaksi Laundry</a><br/>
	<a href="/pelanggan/bajutertukar">Baju Tertukar</a><br/>
	<a href="/logout">Logout</a><br/>
	<h3>Data Pelanggan</h3>
	
	<br/>
	<br/>

	<table border="1">
		Nama : {{ $pelanggan->nama }} <br/>
		Alamat : {{ $pelanggan->alamat }} <br/>
		Handphone : {{ $pelanggan->nohp }} <br/>
		Point Dimiliki : {{ $pelanggan->totalpoint }} <br/>
		<a href="/pelanggan/editpelanggan/{{ $pelanggan->id }}">Edit</a>

	</table>
	<a href="/pelanggan">kembali</a>


</body>
</html>