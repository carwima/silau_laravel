<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Tambah Pelanggan</h3>
	<a href="/admin/datapelanggan">Kembali</a>
	<br/>
	<form action="tambahpelanggan/simpan" method="post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">

      	Nama :
		<input type="text" name="nama"> <br/>
		Alamat :
		<input type="text" name="alamat"> <br/>
		No HP :
		<input type="text" name="nohp"> <br/>
		Username :
		<input type="text" name="uname"> <br/>
		Password :
		<input type="text" name="pass" value="silau_DB"> <br/>
		<input type="hidden" name="totalpoint" value="0"> <br/>
		<input type="submit" value="Simpan">
	</form>

</body>
</html>