<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	
	<h1>Halaman Admin</h1>

	<br>

	<a href="/admin/datapelanggan">Data Pelanggan</a>
	<br/>
	<a href="/admin/datapaket">Paket Laundry</a>
	<br/>
	<a href="/admin/datatransaksi">Transaksi Laundry</a>
	<br/>
	<a href="/logout">Logout</a>

	<h3>Data Transaksi</h3>

	<a href="tambahtransaksi"> + Transaksi Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>ID Transaksi </th>
			<th>ID Pelanggan</th>
			<th>ID Admin</th>
			<th>Tanggal Masuk</th>
			<th>Tanggal Selesai</th>
			<th>Status</th>
			<th>Harga</th>
			<th>Action</th>
		</tr>
		@foreach($transaksi as $t)
		<tr>
			<td>{{ $t->id_Transaksi }}</td>
			<td>{{ $t->id_Pelanggan }}</td>
			<td>{{ $t->id_Admin }}</td>
			<td>{{ $t->Tgl_masuk }}</td>
			@if($t->Tgl_selesai==NULL){
				<td>Belum Selesai</td>
			}@else{
				<td>{{$t->Tgl_selesai}}</td>
			}
			@endif
			@if($t->StatusTransaksi==1){
				<td>Selesai.</td>
			}@else{
				<td>Proses.</td>
			}
			@endif
			<td>{{ $t->harga }}</td>
			<td>
				<a href="/admin/detailtransaksi/{{ $t->id_Transaksi }}">Details</a>
				|
				<a href="/admin/selesaitransaksi/{{ $t->id_Transaksi }}">Selesai</a>
				|
				<a href="/admin/bayartransaksi/{{ $t->id_Transaksi }}">Bayar</a>
				|
				<a href="/admin/hapustransaksi/{{ $t->id_Transaksi }}">Hapus</a>
			</td>
		</tr>
		@endforeach
	</table>
	
	<a href="/admin">kembali</a>


</body>
</html>