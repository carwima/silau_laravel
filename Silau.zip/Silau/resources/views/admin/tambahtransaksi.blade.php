<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Tambah Transaksi</h3>
	<a href="/admin/datatransaksi">Kembali</a>
	<br/>
	ID Transaksi : {{$nextid->id}}
	<form action="tambahtransaksi/simpan" method="post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
		<input type="hidden" name="id" value="{{$nextid->id}}"> 
		ID Pelanggan :
		<input type="text" name="id_pelanggan" required> <br/>
		ID Admin : {{$admin}}
		<input type="hidden" name="id_admin" value='{{$admin}}'> <br/>
		Tanggal masuk : {{$tanggal}}<br>
		Paket yang dipilih :
		<select name="id_paket">
			@foreach($paket as $p)
			<option value="{{$p->id}}">{{$p->NamaPaket}}</option>
			@endforeach
		</select><br/>
		Berat :
		<input type="text" name="berat"  required> <br/>
		<input type="submit" value="Simpan">
	</form>
</body>
</html>