<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h1>Halaman Admin</h1>

	<br>


	<a href="/admin/datapelanggan">Data Pelanggan</a>
	<br/>
	<a href="/admin/datapaket">Paket Laundry</a>
	<br/>
	<a href="/admin/datatransaksi">Transaksi Laundry</a>
	<br/>
	<a href="/admin/datatertukar">Baju Tertukar</a>
	<br/>
	<a href="/logout">Logout</a>
	<h3>Data Pelanggan</h3>

	<a href="tambahpelanggan"> + Tambah Pelanggan Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>nama</th>
			<th>alamat</th>
			<th>nohp</th>
			<th>totalpoint</th>
		</tr>
		@foreach($pelanggan as $p)
		<tr>
			<td>{{ $p->nama }}</td>
			<td>{{ $p->alamat }}</td>
			<td>{{ $p->nohp }}</td>
			<td>{{ $p->totalpoint }}</td>
			<td>
				<a href="/admin/editpelanggan/{{ $p->id }}">Edit</a>
				|
				<a href="/admin/hapus/{{ $p->id }}">Hapus</a>
			</td>
		</tr>
		@endforeach
	</table>
	<a href="/admin">kembali</a>


</body>
</html>