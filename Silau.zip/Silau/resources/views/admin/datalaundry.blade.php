<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h1>Halaman Admin</h1>

	<br>

	<a href="/admin/datapelanggan">Data Pelanggan</a>
	<br/>
	<a href="/admin/datapaket">Paket Laundry</a>
	<br/>
	<a href="/admin/datatransaksi">Transaksi Laundry</a>
	<br/>
	<a href="/admin/datatertukar">Baju Tertukar</a>
	<br/>
	<a href="/logout">Logout</a>
	<h3>Data Paket</h3>

	<a href="tambahpaket"> + Paket Baru</a>
	
	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>Nama Paket</th>
			<th>Deskripsi</th>
			<th>Harga</th>
			<th>Point Didapat</th>
		</tr>
		@foreach($paket as $p)
		<tr>
			<td>{{ $p->NamaPaket }}</td>
			<td>{{ $p->deskripsi }}</td>
			<td>{{ $p->harga }}</td>
			<td>{{ $p->PointDidapat }}</td>
			<td>
				<a href="/admin/editpaket/{{ $p->id }}">Edit</a>
				|
				<a href="/admin/hapuspaket/{{ $p->id }}">Hapus</a>
			</td>
		</tr>
		@endforeach
	</table>
	<a href="/admin">kembali</a>


</body>
</html>