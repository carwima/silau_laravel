<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Edit Paket</h3>

	<a href="/admin/datapaket">Kembali</a>
	<br/>
	@foreach($paket as $p)
	<form action="simpan" method="post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
		<input type="hidden" name="id" value="{{ $p->id }}"> <br/>
      	Nama Paket :
		<input type="text" name="NamaPaket" value="{{ $p->NamaPaket }}"> <br/>
		Deskripsi :
		<input type="text" name="deskripsi" value="{{ $p->deskripsi }}"> <br/>
		Harga (per KG) :
		<input type="text" name="harga" value="{{ $p->harga }}"> <br/>
		Point Didapat(Per KG) :
		<input type="text" name="PointDidapat" value="{{ $p->PointDidapat }}"> <br/>
		<input type="submit" value="Simpan">
	</form>
	@endforeach
</body>
</html>