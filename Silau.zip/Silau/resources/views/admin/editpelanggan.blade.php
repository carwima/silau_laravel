<!DOCTYPE html>
<html>
<head>
	<title>SILAU.COM</title>
</head>
<body>
	<h3>Edit Pelanggan</h3>

	<a href="/admin/datapelanggan">Kembali</a>
	<br/>
	@foreach($pelanggan as $p)
	<form action="simpan" method="post">
		<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
		<input type="hidden" name="id" value="{{ $p->id }}"> <br/>
      	Nama :
		<input type="text" name="nama" value="{{ $p->nama }}"> <br/>
		Alamat :
		<input type="text" name="alamat" value="{{ $p->alamat }}"> <br/>
		No HP :
		<input type="text" name="nohp" value="{{ $p->nohp }}"> <br/>
		Username :
		<input type="text" name="uname" value="{{ $p->uname }}"> <br/>
		<input type="text" name="pass" value="{{ $p->pass }}" hidden> <br/>
		<input type="hidden" name="totalpoint" value="{{ $p->totalpoint }}"> <br/>
		<input type="submit" value="Simpan">
	</form>
	@endforeach
</body>
</html>