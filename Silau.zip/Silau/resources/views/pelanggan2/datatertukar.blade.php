<!DOCTYPE html>
<html lang="en">

@include('pelanggan2.partials.head')

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    @include('pelanggan2.partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        @include('pelanggan2.partials.topnavbar')
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Data Baju Tertukar</h1>
          <p class="mb-4">Data Baju Tertukar SILAU</a></p>
          <a href="/pelanggan/tambahtertukar" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-exclamation-triangle fa-sm text-white-50"></i> Laporkan Pakaian Tertukar</a>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">List Data Baju Tertukar</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                        <th>Pelanggan</th>
                        <th>Transaksi</th>
                        <th>Gambar</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                        <th>Pelanggan</th>
                        <th>Transaksi</th>
                        <th>Gambar</th>
                    </tr>
                  </tfoot>
                  <tbody>
                    @foreach($tertukar as $p)
                    <tr>
                        <td>{{ $p->id_Pelanggan }}</td>
                        <td>{{ $p->id_Transaksi }}</td>
                        <td><img src="{{ asset('images/' . $p->deskripsi) }}" width="200"/></td>
                    </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      @include('pelanggan2.partials.footer')

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

    @include('pelanggan2.partials.scripts')
</body>

</html>
