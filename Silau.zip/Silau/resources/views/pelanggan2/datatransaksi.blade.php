<!DOCTYPE html>
<html lang="en">

@include('pelanggan2.partials.head')

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    @include('pelanggan2.partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        @include('pelanggan2.partials.topnavbar')
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Riwayat Transaksi</h1>
          <p class="mb-4">Riwayat Transaksi</a></p>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Riwayat Transaksi</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                        <th>ID Transaksi </th>	
                        <th>ID Admin</th>
                        <th>Tanggal Masuk</th>
                        <th>Tanggal Selesai</th>
                        <th>Status</th>
                        <th>Harga</th>
                        <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                        <th>ID Transaksi </th>	
                        <th>ID Admin</th>
                        <th>Tanggal Masuk</th>
                        <th>Tanggal Selesai</th>
                        <th>Status</th>
                        <th>Harga</th>
                        <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
                    @foreach($transaksi as $t)
                    <tr>
                        <td>{{ $t->id_Transaksi }}</td>
                        <td>{{ $t->id_Admin }}</td>
                        <td>{{ $t->Tgl_masuk }}</td>
                        @if($t->Tgl_selesai==NULL)
                            <td>Belum Selesai</td>
                        @else
                            <td>{{$t->Tgl_selesai}}</td>
                        
                        @endif
                        @if($t->StatusTransaksi==1)
                            <td>Selesai.</td>
                        @else
                            <td>Proses.</td>
                        @endif
                        <td>{{ $t->harga }}</td>
                        <td>
                            <a href="/pelanggan/detailtransaksi/{{ $t->id_Transaksi }}">INVOICE</a>
                        </td>
                    </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      @include('pelanggan2.partials.footer')

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

    @include('pelanggan2.partials.scripts')
</body>

</html>
