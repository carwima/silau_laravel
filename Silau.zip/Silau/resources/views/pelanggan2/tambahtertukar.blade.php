<!DOCTYPE html>
<html lang="en">

@include('pelanggan2.partials.head')
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    @include('pelanggan2.partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      @include('pelanggan2.partials.topnavbar')

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Laporan pakaian tertukar</h1></div>
          <form action="tambahtertukar/simpan" method="post" enctype="multipart/form-data">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
            <div class="form-group">
                <label for="id_Transaksi">ID Transaksi</label>
                <input type="text" class="form-control" name="id_Transaksi" placeholder="ID Transaksi">
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <input type="file" name="image" class="form-control"><br/>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    @include('pelanggan2.partials.footer')
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  @include('pelanggan2.partials.scripts')
</body>
</html>
