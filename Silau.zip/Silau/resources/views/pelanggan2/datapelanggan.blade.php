<!DOCTYPE html>
<html lang="en">

@include('pelanggan2.partials.head')
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    @include('pelanggan2.partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">



      @include('pelanggan2.partials.topnavbar')

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Diri</h1></div>
        
          <form>
            <div class="form-group">
                <label for="nama">ID</label>
                <input type="text" class="form-control" name="nama" placeholder="Nama"  value="{{ $pelanggan->id }}" disabled>
            </div>
            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" name="nama" placeholder="Nama"  value="{{ $pelanggan->nama }}" disabled>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" class="form-control" name="alamat" placeholder="Alamat"  value="{{ $pelanggan->alamat }}" disabled>
            </div>
            <div class="form-group">
                <label for="nohp">No HP</label>
                <input type="text" class="form-control" name="nohp" placeholder="No HP" value="{{ $pelanggan->nohp }}" disabled>
            </div>
            <div class="form-group">
                <label for="nohp">Username</label>
                <input type="text" class="form-control" name="uname" placeholder="Username" value="{{ $pelanggan->uname }}" disabled>
            </div>
            <a href="/pelanggan/editpelanggan/{{ $pelanggan->id }}" class="btn btn-primary">Edit</a>
          </form>
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

    @include('pelanggan2.partials.footer')
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  @include('pelanggan2.partials.scripts')
</body>
</html>
